﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace search
{
    class Program
    {
        static void Main(string[] args)
        {
            string sourceFolder = @"F:\tetherfi";
            Console.WriteLine("Enter Word to search");
            string wordSearch = Console.ReadLine();
            int count = 0;

            List<string> allFiles = new List<string>();
            AddFileNamesToList(sourceFolder, allFiles);
            foreach (string fileName in allFiles)
            {
                string contents = File.ReadAllText(fileName);
                if (contents.Contains(wordSearch))
                {
                    count = count + 1;
                    Console.WriteLine(fileName);
                }
               
            }
            Console.WriteLine(wordSearch + " Found in " + count + " Files ");
            if (count == 0)
            {
                Console.WriteLine("Not Found");

            };

            System.Console.ReadKey();
        }

        public static void AddFileNamesToList(string sourceDir, List<string> allFiles)
        {

            string[] files = Directory.GetFiles(sourceDir);
            foreach (string fileName in files)
            {
                allFiles.Add(fileName);
            }

              
            string[] subdirectory = Directory.GetDirectories(sourceDir);
            foreach (string item in subdirectory)
            {
                
                if ((File.GetAttributes(item) & FileAttributes.ReparsePoint) != FileAttributes.ReparsePoint)
                {
                    AddFileNamesToList(item, allFiles);
                }
            }
        }
          
    }
}
